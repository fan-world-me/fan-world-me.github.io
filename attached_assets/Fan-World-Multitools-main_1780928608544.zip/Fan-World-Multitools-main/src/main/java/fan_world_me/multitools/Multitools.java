package fan_world_me.multitools;

import net.fabricmc.api.ModInitializer;

public class Multitools implements ModInitializer {
   public static final String MOD_ID = "multitools";

   @Override
   public void onInitialize() {
   }
}
